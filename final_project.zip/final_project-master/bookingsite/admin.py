from django.contrib import admin
from .models import Hotel,Customer
# Register your models here.
admin.site.register(Hotel)
admin.site.register(Customer)