from django.apps import AppConfig


class BookingsiteConfig(AppConfig):
    name = 'bookingsite'
